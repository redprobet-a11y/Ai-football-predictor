# AI Football by redsamoray

Arabic UI, green stadium background, female TTS hint. Upload to GitHub and deploy to Heroku or Render. Do NOT put OPENAI_API_KEY in app.py; use environment variables on your host.
