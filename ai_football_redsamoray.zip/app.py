# AI Football Predictor - Flask app (Arabic UI, green stadium background)
# IMPORTANT: Do NOT put your OPENAI_API_KEY in this file.
from flask import Flask, request, jsonify, render_template_string
import os, json, openai

OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
if not OPENAI_API_KEY:
    print("WARNING: OPENAI_API_KEY not set in environment variables. Predictions will fail until set.")

openai.api_key = OPENAI_API_KEY

app = Flask(__name__)

INDEX_HTML = '''<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AI Football by redsamoray - توقعات المباريات</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;600;800&display=swap');
    :root{
      --green1:#0b6623;
      --green2:#19a974;
      --card: rgba(255,255,255,0.04);
      --accent:#06b6d4;
    }
    html,body{height:100%; margin:0; font-family:Inter, Arial, sans-serif; background: radial-gradient(ellipse at center, rgba(15,77,32,0.85), rgba(6,32,10,0.95)); color:#e6eef8;}
    /* stadium faint lines SVG as background */
    body::before{
      content:"";
      position:fixed; inset:0; z-index:0; opacity:0.12;
      background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800"><rect width="100%" height="100%" fill="%23051207"/><g fill="none" stroke="%23ffffff" stroke-opacity="0.06" stroke-width="2"><rect x="60" y="60" width="1080" height="680" rx="20"/><path d="M120 400 h960" /><path d="M600 60 v680" /><circle cx="600" cy="400" r="60"/></g></svg>');
      background-repeat:no-repeat; background-position:center; background-size:cover;
    }
    .container{position:relative; z-index:2; max-width:980px; margin:24px auto; padding:18px}
    .card{background:var(--card); padding:18px; border-radius:14px; box-shadow: 0 6px 18px rgba(0,0,0,0.5);}
    .header{display:flex; align-items:center; gap:12px}
    .logo{background:linear-gradient(90deg,var(--green1),var(--green2)); padding:10px 14px; border-radius:10px; font-weight:800; color:#fff; box-shadow: 0 6px 12px rgba(6,128,70,0.2)}
    h1{margin:0; font-size:18px}
    label{display:block; margin-top:10px; font-weight:600}
    input, select, textarea{width:100%; padding:10px; margin-top:6px; border-radius:10px; border:1px solid rgba(255,255,255,0.06); background: rgba(255,255,255,0.02); color:#fff}
    button{padding:10px 14px; border-radius:10px; border:none; background:linear-gradient(90deg,var(--green2),#06b6d4); color:#04203a; font-weight:800; cursor:pointer}
    .controls{display:flex; gap:8px; margin-top:12px}
    .status{margin-top:12px; font-weight:700}
    .chrono{font-size:26px; font-weight:800; margin-top:6px}
    .result{margin-top:14px; padding:12px; border-radius:10px; background:rgba(255,255,255,0.02)}
    pre {white-space:pre-wrap; word-wrap:break-word; color:#dff9e1}
    .small{font-size:13px; color: #bfe8c9}
  </style>
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="header">
        <div class="logo">AI Football</div>
        <div>
          <h1>AI Football by redsamoray</h1>
          <div class="small">تطبيق توقعات المباريات - واجهة عربية وصوت نسائي</div>
        </div>
      </div>

      <label>اسم الفريق (المنزل)</label>
      <input id="teamA" placeholder="مثال: JK Poseidon">

      <label>آخر 5 نتائج للفريق (A) — مثال: W,L,D,W,L</label>
      <input id="lastA" placeholder="W,L,D,W,L">

      <label>اسم الفريق (الضيف)</label>
      <input id="teamB" placeholder="مثال: Tartu Welco">

      <label>آخر 5 نتائج للفريق (B)</label>
      <input id="lastB" placeholder="W,D,L,W,L">

      <label>اختر مدة البحث (كرونو)</label>
      <select id="seconds">
        <option value="30">30 ثانية</option>
        <option value="60">60 ثانية</option>
      </select>

      <div class="controls">
        <button id="analyze">ابدأ التحليل</button>
        <button id="stop" style="background:#ef4444">أوقف</button>
      </div>

      <div class="status" id="status">مستعد</div>
      <div class="chrono" id="chronometer"></div>

      <div class="result" id="resultBox" style="display:none">
        <h3>النتيجة المتوقعة</h3>
        <pre id="resultJson"></pre>
        <button id="speakBtn">نطق النتيجة بصوت نسائي</button>
      </div>
    </div>
  </div>

<script>
const analyzeBtn = document.getElementById('analyze')
const stopBtn = document.getElementById('stop')
const statusEl = document.getElementById('status')
const chron = document.getElementById('chronometer')
const resultBox = document.getElementById('resultBox')
const resultJson = document.getElementById('resultJson')
const speakBtn = document.getElementById('speakBtn')
let timer = null, remaining = 0

function speak(text){
  if(!('speechSynthesis' in window)) return
  window.speechSynthesis.cancel()
  const u = new SpeechSynthesisUtterance(text)
  u.lang = 'ar-SA'
  // try to pick a female voice if available
  const voices = window.speechSynthesis.getVoices()
  for(const v of voices){
    if((/female|woman|zira|amina|amal|leila|hala/i).test(v.name) || (/voice.*female/i).test(v.name)){
      u.voice = v; break;
    }
  }
  window.speechSynthesis.speak(u)
}

analyzeBtn.onclick = async ()=>{
  const teamA = document.getElementById('teamA').value.trim()
  const lastA = document.getElementById('lastA').value.trim()
  const teamB = document.getElementById('teamB').value.trim()
  const lastB = document.getElementById('lastB').value.trim()
  const seconds = parseInt(document.getElementById('seconds').value)
  if(!teamA || !teamB){ alert('دخل أسماء الفريقين'); return }

  remaining = seconds
  chron.textContent = remaining + 's'
  statusEl.innerHTML = '🔎 AI كتقلب على المعطيات... (الرجاء الانتظار)'
  resultBox.style.display = 'none'
  speak('نبدأ التحليل الآن، صبر شوية')

  timer = setInterval(()=>{
    remaining -= 1
    chron.textContent = remaining + 's'
    if(remaining <= 0){ clearInterval(timer); chron.textContent = 'جاري التحليل النهائي...'; sendRequest() }
  },1000)
}

stopBtn.onclick = ()=>{
  clearInterval(timer)
  chron.textContent = ''
  statusEl.textContent = 'موقوف من المستخدم'
  window.speechSynthesis.cancel()
}

async function sendRequest(){
  const teamA = document.getElementById('teamA').value.trim()
  const lastA = document.getElementById('lastA').value.trim()
  const teamB = document.getElementById('teamB').value.trim()
  const lastB = document.getElementById('lastB').value.trim()
  statusEl.textContent = 'إرسال المعطيات للسيرفر...'
  try{
    const resp = await fetch('/predict',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({teamA, lastA, teamB, lastB})
    })
    const data = await resp.json()
    statusEl.textContent = 'تم التوقع - جاهز'
    resultBox.style.display = 'block'
    resultJson.textContent = JSON.stringify(data, null, 2)
    speak('النتيجة المتوقعة: ' + (data.final_score || 'لا توجد نتيجة'))
  }catch(err){
    statusEl.textContent = 'حدث خطأ: ' + (err.message || err)
  }
}

speakBtn.onclick = ()=>{
  const text = resultJson.textContent || ''
  if(!text) return
  speak('ها هي التوقع: ' + text)
}
</script>
</body>
</html>
'''

@app.route('/')
def index():
    return render_template_string(INDEX_HTML)

def build_prompt(teamA, lastA, teamB, lastB, weatherA, weatherB, infoA, infoB):
    system_prompt = (
        "You are an expert football analyst. Given the inputs, produce a final score prediction "
        "and Over/Under decision. Output ONLY valid JSON with keys: final_score (format 'X-Y'), over_under ('Over 2.5' or 'Under 2.5'), confidence (0-100), rationale_short (one-sentence)."
    )
    user_prompt = f"Team A: {teamA}\\nLast results A: {lastA}\\nTeam B: {teamB}\\nLast results B: {lastB}\\nWeather A: {weatherA}\\nWeather B: {weatherB}\\nInfo A: {infoA}\\nInfo B: {infoB}\\nBe concise."
    return system_prompt, user_prompt

@app.route('/predict', methods=['POST'])
def predict():
    payload = request.get_json(force=True)
    teamA = payload.get('teamA','').strip()
    teamB = payload.get('teamB','').strip()
    lastA = payload.get('lastA','')
    lastB = payload.get('lastB','')

    weatherA = {'summary': 'unknown', 'temp_c': None}
    weatherB = {'summary': 'unknown', 'temp_c': None}
    infoA = {'available': 'none', 'notes': 'demo'}
    infoB = {'available': 'none', 'notes': 'demo'}

    system_prompt, user_prompt = build_prompt(teamA, lastA, teamB, lastB, weatherA, weatherB, infoA, infoB)

    if not OPENAI_API_KEY:
        return jsonify({'error': 'OPENAI_API_KEY not set on server. Set it as environment variable.'}), 500
    try:
        resp = openai.ChatCompletion.create(
            model='gpt-4o-mini',
            messages=[{'role':'system','content':system_prompt},{'role':'user','content':user_prompt}],
            max_tokens=300,
            temperature=0.25,
        )
        text = resp['choices'][0]['message']['content'].strip()
        try:
            parsed = json.loads(text)
        except Exception:
            import re
            m = re.search(r"\{[\s\S]*\}", text)
            if m:
                try:
                    parsed = json.loads(m.group(0))
                except Exception:
                    parsed = {'error':'failed_to_parse','raw':text}
            else:
                parsed = {'error':'no_json','raw':text}
        parsed['_meta'] = {'model_raw': text}
        return jsonify(parsed)
    except Exception as e:
        return jsonify({'error':'openai_call_failed','details':str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', 5000)))